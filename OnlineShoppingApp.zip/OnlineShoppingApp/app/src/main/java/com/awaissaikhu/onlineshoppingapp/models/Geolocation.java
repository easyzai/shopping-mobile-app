package com.awaissaikhu.onlineshoppingapp.models;

public class Geolocation {
    double lat;
    double Long;

    public Geolocation() {
    }

    public double getLat() {
        return lat;
    }

    public void setLat(double lat) {
        this.lat = lat;
    }

    public double getLong() {
        return Long;
    }

    public void setLng(double Long) {
        this.Long = Long;
    }
}
