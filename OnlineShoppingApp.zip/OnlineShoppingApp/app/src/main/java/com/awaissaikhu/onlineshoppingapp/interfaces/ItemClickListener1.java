package com.awaissaikhu.onlineshoppingapp.interfaces;

import android.view.View;


public interface ItemClickListener1 {
    void onPositionClicked(View view, int position);
    void onLongClicked(int position);

}
