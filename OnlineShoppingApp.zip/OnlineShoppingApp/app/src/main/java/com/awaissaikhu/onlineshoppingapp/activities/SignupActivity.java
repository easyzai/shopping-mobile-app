package com.awaissaikhu.onlineshoppingapp.activities;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.awaissaikhu.onlineshoppingapp.R;
import com.awaissaikhu.onlineshoppingapp.models.Address;
import com.awaissaikhu.onlineshoppingapp.models.Geolocation;
import com.awaissaikhu.onlineshoppingapp.models.Name;
import com.awaissaikhu.onlineshoppingapp.models.User;
import com.awaissaikhu.onlineshoppingapp.viewmodel.UserData;
import com.google.gson.Gson;

import org.json.JSONObject;

public class SignupActivity extends AppCompatActivity {
EditText edtemail,edtusername,edtpassword,edtfirstname,edtlastname,edtstreet,edtcity,edtnumber,edtzip,edtphone;
   CardView cardsingup;
   ImageView imgback;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
        edtemail=findViewById(R.id.edtemail);
        edtusername=findViewById(R.id.edtusername);
        edtpassword=findViewById(R.id.edtpassword);
        edtfirstname=findViewById(R.id.edtfirstname);
        edtlastname=findViewById(R.id.edtlastname);
        edtstreet=findViewById(R.id.edtstreet);
        edtnumber=findViewById(R.id.edtstn);
        edtcity=findViewById(R.id.edtcity);
        edtzip=findViewById(R.id.edtzipcode);
        edtphone=findViewById(R.id.edtphone);
        cardsingup=findViewById(R.id.cardsignup);
        imgback=findViewById(R.id.imgback);
        imgback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
        cardsingup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(TextUtils.isEmpty(edtemail.getText().toString())||TextUtils.isEmpty(edtusername.getText().toString())||TextUtils.isEmpty(edtpassword.getText().toString())||TextUtils.isEmpty(edtcity.getText().toString())||TextUtils.isEmpty(edtstreet.getText().toString())||TextUtils.isEmpty(edtzip.getText().toString())||TextUtils.isEmpty(edtphone.getText().toString())||TextUtils.isEmpty(edtfirstname.getText().toString())||TextUtils.isEmpty(edtlastname.getText().toString())||TextUtils.isEmpty(edtnumber.getText().toString()))
                {
                    Toast.makeText(SignupActivity.this, "Please Fill all the fields", Toast.LENGTH_SHORT).show();
                }
                else{
                    User u=new User();
                    Address address=new Address();
                    Geolocation geolocation=new Geolocation();
                    geolocation.setLat(34.232323);
                    geolocation.setLng(32.23233);
                    address.setGeolocation(geolocation);
                    address.setCity(edtcity.getText().toString());
                    address.setNumber(Integer.parseInt(edtnumber.getText().toString()));
                    address.setStreet(edtstreet.getText().toString());
                    address.setZipcode(edtzip.getText().toString());
                    Name name=new Name();
                    name.setFirstname(edtfirstname.getText().toString());
                    name.setLastname(edtlastname.getText().toString());
                    u.setName(name);
                    u.setAddress(address);
                    u.setEmail(edtemail.getText().toString());
                    u.setPassword(edtpassword.getText().toString());
                    u.setUsername(edtusername.getText().toString());
                    u.setPhone(edtphone.getText().toString());
                    new UserData().Signup(u,SignupActivity.this);


                }
            }
        });

    }

    public void response(JSONObject response) {
        if(response!=null){
            User u=new Gson().fromJson(response.toString(),User.class);
            finish();
              }

    }
}