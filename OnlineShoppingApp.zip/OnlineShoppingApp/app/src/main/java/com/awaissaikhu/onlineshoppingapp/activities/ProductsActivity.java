package com.awaissaikhu.onlineshoppingapp.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.awaissaikhu.onlineshoppingapp.R;
import com.awaissaikhu.onlineshoppingapp.models.CartProduct;
import com.awaissaikhu.onlineshoppingapp.models.Order;

import java.util.ArrayList;

public class ProductsActivity extends AppCompatActivity {
Order order;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_products);
        order= (Order) getIntent().getSerializableExtra("order");
        OrderProductAdapter adapter = new OrderProductAdapter(this, order.getProducts());

        ListView listView = (ListView) findViewById(R.id.listview);
        listView.setAdapter(adapter);


    }
    public class OrderProductAdapter extends ArrayAdapter<CartProduct> {
        public OrderProductAdapter(Context context, CartProduct[] cartproducts) {
            super(context, 0, cartproducts);
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            CartProduct cartProduct = getItem(position);
            if (convertView == null) {
                convertView = LayoutInflater.from(getContext()).inflate(R.layout.singleorder, parent, false);
            }
             TextView tvName = (TextView) convertView.findViewById(R.id.txttitle);
            TextView tvHome = (TextView) convertView.findViewById(R.id.txtprice);
            tvName.setText("Product ID : "+cartProduct.getProductId()+"");
            tvHome.setText("Product Qnty : "+cartProduct.getQuantity()+"");
            convertView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    startActivity(new Intent(ProductsActivity.this,SingleProductActivity.class).putExtra("productid",getItem(position).getProductId()));
                }
            });
            return convertView;
        }
    }
}