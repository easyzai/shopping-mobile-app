package com.awaissaikhu.onlineshoppingapp.viewmodel;

import android.util.Log;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.awaissaikhu.onlineshoppingapp.activities.LoginActivity;
import com.awaissaikhu.onlineshoppingapp.activities.SignupActivity;
import com.awaissaikhu.onlineshoppingapp.activities.SingleProductActivity;
import com.awaissaikhu.onlineshoppingapp.fragments.CartFragment;
import com.awaissaikhu.onlineshoppingapp.fragments.ProfileFragment;
import com.awaissaikhu.onlineshoppingapp.models.CartProduct;
import com.awaissaikhu.onlineshoppingapp.models.Product;
import com.awaissaikhu.onlineshoppingapp.models.User;
import com.awaissaikhu.onlineshoppingapp.requests.MySingleton;
import com.google.gson.Gson;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

public class UserData {
    public void login(LoginActivity loginActivity,String username,String password) {
        String url = "https://fakestoreapi.com/auth/login";


        JSONObject body = new JSONObject();
        String jsonBody;
        try {
            body.put("username",username);
            body.put("password",password);

//            Toast.makeText(getActivity(), "In Nudity Present func 1", Toast.LENGTH_SHORT).show();

        } catch (JSONException e) {

        }



        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest
                (Request.Method.POST, url, body, new Response.Listener<JSONObject>() {


                    @Override
                    public void onResponse(JSONObject response) {

                        loginActivity.response(response);

                    }
                }, new Response.ErrorListener() {

                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // TODO: Handle error
                        Toast.makeText(loginActivity, "Incorrect Detail", Toast.LENGTH_SHORT).show();
                        loginActivity.response(null);

                    }
                });
        MySingleton.getInstance(loginActivity).addToRequestQueue(jsonObjectRequest);

    }
    public void Signup(User user, SignupActivity c){

        String url = "https://fakestoreapi.com/users";


        JSONObject body = null;
        try {
            body = new JSONObject(new Gson().toJson(user));
        } catch (JSONException e) {
            e.printStackTrace();
        }


        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest
                (Request.Method.POST, url, body, new Response.Listener<JSONObject>() {


                    @Override
                    public void onResponse(JSONObject response) {

                        c.response(response);
                        Toast.makeText(c,"User Signup Successfully", Toast.LENGTH_SHORT).show();

                    }
                }, new Response.ErrorListener() {

                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // TODO: Handle error
                        Toast.makeText(c, "Some error occured", Toast.LENGTH_SHORT).show();
                        c.response(null);

                    }
                });
        MySingleton.getInstance(c).addToRequestQueue(jsonObjectRequest);


    }
    public void getsingleuser(ProfileFragment p, int userid) {
        String url = "https://fakestoreapi.com/users/"+userid;


        StringRequest MyStringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);

                    User u =new Gson().fromJson(jsonObject.toString(),User.class);

                    p.notifiy(u);


                } catch (JSONException e) {
                    e.printStackTrace();
                    Toast.makeText(p.getActivity(), "Json"+e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
                }


            }
        }, new Response.ErrorListener() { //Create an error listener to handle errors appropriately.
            @Override
            public void onErrorResponse(VolleyError error) {
                //This code is executed if there is an error.
                if(error!=null)
                    Log.e("error",error.getLocalizedMessage()+"");

            }
        }) {
            protected Map<String, String> getParams() {
                Map<String, String> MyData = new HashMap<String, String>();

//Add the data you'd like to send to the server.
                return MyData;
            }
        };

        MyStringRequest.setRetryPolicy(new DefaultRetryPolicy(
                20 * 1000,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        MySingleton.getInstance(p.getActivity()).addToRequestQueue(MyStringRequest);

    }

}
