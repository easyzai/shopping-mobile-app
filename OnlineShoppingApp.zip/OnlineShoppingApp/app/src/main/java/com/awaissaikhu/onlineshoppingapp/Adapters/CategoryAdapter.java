package com.awaissaikhu.onlineshoppingapp.Adapters;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.awaissaikhu.onlineshoppingapp.R;
import com.awaissaikhu.onlineshoppingapp.interfaces.ItemClickListener1;
import com.awaissaikhu.onlineshoppingapp.models.Product;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;


public class CategoryAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {


        PlacesViewHolder placesViewHolder=null;
    Context context;
    ArrayList<String> Categories;
    ItemClickListener1 itemClickListener1;
    public CategoryAdapter(Context context, ArrayList<String> Categories, ItemClickListener1 itemClickListener1) {
        this.context = context;
        this.Categories = Categories;
        this.itemClickListener1=itemClickListener1;
    }


    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {


        View view;

            view = LayoutInflater.from(parent.getContext()).inflate(R.layout.singlecategory, parent, false);

            PlacesViewHolder placesViewHolder = new PlacesViewHolder(view,itemClickListener1);


            return placesViewHolder;



    }

    @Override
    public int getItemViewType(int position) {


        return position;
    }
int selected=0;
    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {

            placesViewHolder = (PlacesViewHolder) holder;
            placesViewHolder.txttitle.setText( Categories.get(position));
            if(position==selected){
                placesViewHolder.txttitle.setTextColor(Color.BLUE);
            }
            else
                placesViewHolder.txttitle.setTextColor(Color.BLACK);
            placesViewHolder.txttitle.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    itemClickListener1.onPositionClicked(view,position);
                    selected=position;
                    notifyDataSetChanged();

                }
            });

    }

    @Override
    public int getItemCount() {
        return Categories.size();
    }

    public static class PlacesViewHolder extends RecyclerView.ViewHolder  {

        View view;
        TextView txttitle;
        ItemClickListener1 itemClickListener1;


        public PlacesViewHolder(View itemView, ItemClickListener1 listener1) {
            super(itemView);
            itemClickListener1=listener1;
            view = itemView;

            txttitle = (TextView) view.findViewById(R.id.txttitle);



        }


    }



}
