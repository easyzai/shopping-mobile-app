package com.awaissaikhu.onlineshoppingapp.fragments;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.awaissaikhu.onlineshoppingapp.Adapters.CategoryAdapter;
import com.awaissaikhu.onlineshoppingapp.Adapters.ProductAdapter;
import com.awaissaikhu.onlineshoppingapp.R;
import com.awaissaikhu.onlineshoppingapp.interfaces.ItemClickListener1;
import com.awaissaikhu.onlineshoppingapp.models.Product;
import com.awaissaikhu.onlineshoppingapp.viewmodel.CategoryData;
import com.awaissaikhu.onlineshoppingapp.viewmodel.ProductData;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link ShopFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class ShopFragment extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public ShopFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment ShopFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static ShopFragment newInstance(String param1, String param2) {
        ShopFragment fragment = new ShopFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }
ArrayList<Product> products;
ArrayList<String> categories;
    CategoryAdapter categoryAdapter;
    ProductAdapter productAdapter;
    ProductData productData;
    CategoryData categoryData;
    RecyclerView recyclerView,categoryiesrecyler;
    SwipeRefreshLayout swip;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v= inflater.inflate(R.layout.fragment_shop, container, false);
         recyclerView=v.findViewById(R.id.productrecyler);
        swip=v.findViewById(R.id.swip);
        categoryiesrecyler=v.findViewById(R.id.categoryrecyler);
        categoryiesrecyler.setLayoutManager(new LinearLayoutManager(getActivity(),RecyclerView.HORIZONTAL,false));
        recyclerView.setLayoutManager(new GridLayoutManager(getActivity(),2));
       products= new ArrayList<>();
       productData= new ProductData();
       categoryData= new CategoryData();
       categories= new ArrayList<>();


        return v;
    }
public void notifiy(ArrayList<Product> pro){
    products.addAll(pro);
    productAdapter=new ProductAdapter(getActivity(), products);
    recyclerView.setAdapter(productAdapter);
    swip.setRefreshing(false);
}
    @Override
    public void onResume() {
        super.onResume();
        categoryData.getallcat(this);
        productData.getallproducts(this);
        swip.setRefreshing(true);


    }

    public void notifiycategory(ArrayList<String> category) {
        categories.clear();
        categories.add("All");
        categories.addAll(category);

        categoryAdapter=new CategoryAdapter(getActivity(), categories, new ItemClickListener1() {
            @Override
            public void onPositionClicked(View view, int position) {
                products.clear();
                productAdapter.notifyDataSetChanged();
                if(position==0){

                    productData.getallproducts(ShopFragment.this);
                }
                else
                productData.getcatproducts(categories.get(position),ShopFragment.this);
            }

            @Override
            public void onLongClicked(int position) {

            }
        });
        categoryiesrecyler.setAdapter(categoryAdapter);
    }
}