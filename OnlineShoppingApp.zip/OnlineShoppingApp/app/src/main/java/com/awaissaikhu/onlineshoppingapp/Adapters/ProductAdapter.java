package com.awaissaikhu.onlineshoppingapp.Adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.awaissaikhu.onlineshoppingapp.R;
import com.awaissaikhu.onlineshoppingapp.activities.SingleProductActivity;
import com.awaissaikhu.onlineshoppingapp.models.Product;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;


public class ProductAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {


        PlacesViewHolder placesViewHolder=null;
    Context context;
    ArrayList<Product> products;
    public ProductAdapter(Context context, ArrayList<Product> products) {
        this.context = context;
        this.products = products;
    }


    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {


        View view;

            view = LayoutInflater.from(parent.getContext()).inflate(R.layout.singleproduct, parent, false);

            PlacesViewHolder placesViewHolder = new PlacesViewHolder(view);


            return placesViewHolder;



    }

    @Override
    public int getItemViewType(int position) {


        return position;
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {

            placesViewHolder = (PlacesViewHolder) holder;
            placesViewHolder.txttitle.setText( products.get(position).getTitle());
            placesViewHolder.txtprice.setText("£ "+ products.get(position).getPrice());
            placesViewHolder.txtrating.setText( "("+products.get(position).getRating().getCount()+")");
            placesViewHolder.ratingBar.setRating(products.get(position).getRating().getRate());
            Picasso.get().load( products.get(position).getImage()).error(R.drawable.shoppingbag).into(placesViewHolder.imageView);
        placesViewHolder.view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                context.startActivity(new Intent(context, SingleProductActivity.class).putExtra("product",products.get(position)));
            }
        });

    }

    @Override
    public int getItemCount() {
        return products.size();
    }

    public static class PlacesViewHolder extends RecyclerView.ViewHolder {

        View view;
        TextView txttitle;
        TextView txtprice;
        TextView txtrating;
        RatingBar ratingBar;
        ImageView imageView;


        public PlacesViewHolder(View itemView) {
            super(itemView);
            view = itemView;

            txttitle = (TextView) view.findViewById(R.id.txttitle);
            txtprice = (TextView) view.findViewById(R.id.txtprice);
            txtrating = (TextView) view.findViewById(R.id.txtrating);
            imageView = (ImageView) view.findViewById(R.id.img);
            ratingBar = (RatingBar) view.findViewById(R.id.ratingbar);


        }


    }



}
