package com.awaissaikhu.onlineshoppingapp.viewmodel;

import static java.lang.Integer.parseInt;

import android.content.Context;
import android.graphics.Bitmap;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.awaissaikhu.onlineshoppingapp.activities.SingleProductActivity;
import com.awaissaikhu.onlineshoppingapp.fragments.ShopFragment;
import com.awaissaikhu.onlineshoppingapp.models.Product;
import com.awaissaikhu.onlineshoppingapp.requests.MySingleton;
import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class ProductData {
    public ProductData() {
    }
    ArrayList<Product> products;
    public void getallproducts(ShopFragment c){
        products=new ArrayList<>();
        String url = "https://fakestoreapi.com/products";

        Log.e("products",products.size()+"");
        StringRequest MyStringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                  Log.e("response", response+"");
                try {
                    JSONArray jsonObject = new JSONArray(response);
                        for (int i=0;i<jsonObject.length();i++) {
                            Product p =new Gson().fromJson(jsonObject.getJSONObject(i).toString(),Product.class);
                            products.add(p);

                            Log.e("products",p.getTitle()+"");
                        }

                    Log.e("products",products.size()+"");
                    c.notifiy(products);


                } catch (JSONException e) {
                    e.printStackTrace();
                    Toast.makeText(c.getActivity(), "Json"+e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
                }


            }
        }, new Response.ErrorListener() { //Create an error listener to handle errors appropriately.
            @Override
            public void onErrorResponse(VolleyError error) {
                //This code is executed if there is an error.
                if(error!=null)
                    Log.e("error",error.getLocalizedMessage()+"");

            }
        }) {
            protected Map<String, String> getParams() {
                Map<String, String> MyData = new HashMap<String, String>();

//Add the data you'd like to send to the server.
                return MyData;
            }
        };

        MyStringRequest.setRetryPolicy(new DefaultRetryPolicy(
                20 * 1000,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        MySingleton.getInstance(c.getActivity()).addToRequestQueue(MyStringRequest);

Log.e("products",products.size()+"");
    }
    public void getcatproducts(String cat,ShopFragment c){

        String url = "https://fakestoreapi.com/products/category/"+cat;


        products=new ArrayList<>();

        Log.e("products",products.size()+"");
        StringRequest MyStringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.e("response", response+"");
                try {
                    JSONArray jsonObject = new JSONArray(response);
                    for (int i=0;i<jsonObject.length();i++) {
                        Product p =new Gson().fromJson(jsonObject.getJSONObject(i).toString(),Product.class);
                        products.add(p);

                        Log.e("products",p.getTitle()+"");
                    }

                    Log.e("products",products.size()+"");
                    c.notifiy(products);


                } catch (JSONException e) {
                    e.printStackTrace();
                    Toast.makeText(c.getActivity(), "Json"+e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
                }


            }
        }, new Response.ErrorListener() { //Create an error listener to handle errors appropriately.
            @Override
            public void onErrorResponse(VolleyError error) {
                //This code is executed if there is an error.
                if(error!=null)
                    Log.e("error",error.getLocalizedMessage()+"");

            }
        }) {
            protected Map<String, String> getParams() {
                Map<String, String> MyData = new HashMap<String, String>();

//Add the data you'd like to send to the server.
                return MyData;
            }
        };

        MyStringRequest.setRetryPolicy(new DefaultRetryPolicy(
                20 * 1000,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        MySingleton.getInstance(c.getActivity()).addToRequestQueue(MyStringRequest);

    }

    public void getsingleproduct(SingleProductActivity singleProductActivity, int productid) {
        String url = "https://fakestoreapi.com/products/"+productid;


         StringRequest MyStringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                 try {
                     JSONObject jsonObject = new JSONObject(response);

                        Product p =new Gson().fromJson(jsonObject.toString(),Product.class);

                    singleProductActivity.notifiy(p);


                } catch (JSONException e) {
                    e.printStackTrace();
                    Toast.makeText(singleProductActivity, "Json"+e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
                }


            }
        }, new Response.ErrorListener() { //Create an error listener to handle errors appropriately.
            @Override
            public void onErrorResponse(VolleyError error) {
                //This code is executed if there is an error.
                if(error!=null)
                    Log.e("error",error.getLocalizedMessage()+"");

            }
        }) {
            protected Map<String, String> getParams() {
                Map<String, String> MyData = new HashMap<String, String>();

//Add the data you'd like to send to the server.
                return MyData;
            }
        };

        MyStringRequest.setRetryPolicy(new DefaultRetryPolicy(
                20 * 1000,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        MySingleton.getInstance(singleProductActivity).addToRequestQueue(MyStringRequest);

    }
}
