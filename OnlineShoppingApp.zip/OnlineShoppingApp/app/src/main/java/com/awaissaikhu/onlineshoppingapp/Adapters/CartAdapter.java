package com.awaissaikhu.onlineshoppingapp.Adapters;

import android.content.Context;
import android.graphics.Color;
import android.media.Image;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.awaissaikhu.onlineshoppingapp.R;
import com.awaissaikhu.onlineshoppingapp.interfaces.ItemClickListener1;
import com.awaissaikhu.onlineshoppingapp.utilis.Constants;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;


public class CartAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {


        PlacesViewHolder placesViewHolder=null;
    Context context;
    ItemClickListener1 itemClickListener1;
    public CartAdapter(Context context) {
        this.context = context;
        this.itemClickListener1=itemClickListener1;
    }


    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {


        View view;

            view = LayoutInflater.from(parent.getContext()).inflate(R.layout.singlecartitem, parent, false);

            PlacesViewHolder placesViewHolder = new PlacesViewHolder(view,itemClickListener1);


            return placesViewHolder;



    }

    @Override
    public int getItemViewType(int position) {


        return position;
    }
    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {

            placesViewHolder = (PlacesViewHolder) holder;
            placesViewHolder.txttitle.setText( Constants.cartitems.get(position).getProduct().getTitle());
            placesViewHolder.txtprice.setText( "£ "+Constants.cartitems.get(position).getProduct().getPrice()+"");
            placesViewHolder.txtquantity.setText( "Qnty :"+Constants.cartitems.get(position).getQuantity()+"");
            placesViewHolder.txttotal.setText( "£ "+Constants.cartitems.get(position).getProduct().getPrice()*Constants.cartitems.get(position).getQuantity()+"");
        Picasso.get().load( Constants.cartitems.get(position).getProduct().getImage()).error(R.drawable.shoppingbag).into(placesViewHolder.img);

    }

    @Override
    public int getItemCount() {
        return Constants.cartitems.size();
    }

    public static class PlacesViewHolder extends RecyclerView.ViewHolder  {

        View view;
        TextView txttitle,txtprice,txtquantity,txttotal;
        ImageView img;
        ItemClickListener1 itemClickListener1;


        public PlacesViewHolder(View itemView, ItemClickListener1 listener1) {
            super(itemView);
            itemClickListener1=listener1;
            view = itemView;

            txttitle = (TextView) view.findViewById(R.id.txttitle);
            txtquantity = (TextView) view.findViewById(R.id.txtquantity);
            txtprice = (TextView) view.findViewById(R.id.txtprice);
            txttotal = (TextView) view.findViewById(R.id.txttotal);
            img = (ImageView) view.findViewById(R.id.img);



        }


    }



}
