package com.awaissaikhu.onlineshoppingapp.fragments;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import com.awaissaikhu.onlineshoppingapp.R;
import com.awaissaikhu.onlineshoppingapp.activities.AboutUsActivity;
import com.awaissaikhu.onlineshoppingapp.activities.LoginActivity;
import com.awaissaikhu.onlineshoppingapp.models.User;
import com.awaissaikhu.onlineshoppingapp.utilis.Constants;
import com.awaissaikhu.onlineshoppingapp.viewmodel.UserData;
import com.squareup.picasso.Picasso;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link ProfileFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class ProfileFragment extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public ProfileFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment ProfileFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static ProfileFragment newInstance(String param1, String param2) {
        ProfileFragment fragment = new ProfileFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }
    TextView edtemail,edtfirstname,edtlastname,edtstreet,edtcity,edtnumber,edtzip,edtphone;
ImageView img,imgabout,imglogout;
FrameLayout framelayout;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v= inflater.inflate(R.layout.fragment_profile, container, false);
        framelayout=v.findViewById(R.id.framelayout);
        img=v.findViewById(R.id.img);
        imgabout=v.findViewById(R.id.imgabout);
        imglogout=v.findViewById(R.id.imglogout);
        edtemail=v.findViewById(R.id.edtemail);
        edtfirstname=v.findViewById(R.id.edtfirstname);
        edtlastname=v.findViewById(R.id.edtlastname);
        edtstreet=v.findViewById(R.id.edtstreet);
        edtnumber=v.findViewById(R.id.edtstn);
        edtcity=v.findViewById(R.id.edtcity);
        edtzip=v.findViewById(R.id.edtzipcode);
        edtphone=v.findViewById(R.id.edtphone);
        imgabout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getActivity(), AboutUsActivity.class));
            }
        });
        imglogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                getActivity().getSharedPreferences("onlineapp",Context.MODE_PRIVATE).edit().remove("token").remove("userid").apply();
                getActivity().startActivity(new Intent(getActivity(), LoginActivity.class));
                getActivity().finish();
            }
        });
        Picasso.get().load("https://thispersondoesnotexist.com/image").error(R.drawable.shoppingbag).into(img);

    new UserData().getsingleuser(this,getActivity().getSharedPreferences("onlineapp", Context.MODE_PRIVATE).getInt("userid",1));
        return  v;
    }

    public void notifiy(User u) {
        edtcity.setText(u.getAddress().getCity());
        edtstreet.setText(u.getAddress().getStreet());
        edtnumber.setText(u.getAddress().getNumber()+"");
        edtzip.setText(u.getAddress().getZipcode());
        edtemail.setText(u.getEmail());
        edtfirstname.setText(u.getName().getFirstname());
        edtlastname.setText(u.getName().getLastname());
        edtphone.setText(u.getPhone());
        MapsFragment mapsFragment=MapsFragment.newInstance(u.getAddress().getGeolocation().getLat(),u.getAddress().getGeolocation().getLong());
        FragmentManager fm = getChildFragmentManager();
        fm.beginTransaction().replace(R.id.framelayout, mapsFragment, mapsFragment.getTag()).commit();

    }
}