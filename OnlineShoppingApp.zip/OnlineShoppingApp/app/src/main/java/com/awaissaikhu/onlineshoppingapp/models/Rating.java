package com.awaissaikhu.onlineshoppingapp.models;

import java.io.Serializable;

public class Rating implements Serializable {
    float rate;
    int count;
    public Rating(){

    }

    public float getRate() {
        return rate;
    }

    public void setRate(float rate) {
        this.rate = rate;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }
}
