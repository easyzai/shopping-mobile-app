package com.awaissaikhu.onlineshoppingapp.activities;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.awaissaikhu.onlineshoppingapp.R;
import com.awaissaikhu.onlineshoppingapp.viewmodel.UserData;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Calendar;

public class LoginActivity extends AppCompatActivity {
EditText edtusername,edtpassword;
CardView cardsignin;
ProgressBar progressBar;
TextView txtsignup;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        txtsignup=findViewById(R.id.txtsignup);
        progressBar=findViewById(R.id.progress);
        cardsignin=findViewById(R.id.cardsignin);
        edtusername=findViewById(R.id.edtusername);
        edtpassword=findViewById(R.id.edtpassword);
        cardsignin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(edtusername.getText().toString().length()>0&&edtpassword.getText().toString().length()>0){
                  progressBar.setVisibility(View.VISIBLE);

                    new UserData().login(LoginActivity.this,edtusername.getText().toString(),edtpassword.getText().toString());
                }
                else
                    Toast.makeText(LoginActivity.this, "Please Fill Username and password", Toast.LENGTH_SHORT).show();
            }
        });
        txtsignup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(LoginActivity.this,SignupActivity.class));
            }
        });

    }

    public void response(JSONObject response) {
        try {

            getSharedPreferences("onlineapp",MODE_PRIVATE).edit().putString("token",response.getString("token")).putInt("userid",2).apply();
            startActivity(new Intent(LoginActivity.this,MainActivity.class));
            finish();
        } catch (JSONException e) {
            Toast.makeText(LoginActivity.this, "Incorrect Username Password", Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }

    }
}