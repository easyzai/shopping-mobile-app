package com.awaissaikhu.onlineshoppingapp.viewmodel;

import static android.content.Context.MODE_PRIVATE;
import static java.lang.Integer.parseInt;

import android.util.Log;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.awaissaikhu.onlineshoppingapp.fragments.CartFragment;
import com.awaissaikhu.onlineshoppingapp.fragments.OrderFragment;
import com.awaissaikhu.onlineshoppingapp.models.Order;
import com.awaissaikhu.onlineshoppingapp.models.CartProduct;
import com.awaissaikhu.onlineshoppingapp.requests.MySingleton;
import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

public class OrderData {
    public void getuserorder(OrderFragment c, int id){
     ArrayList<Order> orders =new ArrayList<>();
        String url = "https://fakestoreapi.com/carts/user/"+id;

        StringRequest MyStringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONArray jsonObject = new JSONArray(response);
                    for (int i=0;i<jsonObject.length();i++) {
                         Order c=new Gson().fromJson(jsonObject.getJSONObject(i).toString(), Order.class);
                            orders.add(c);

                    }


                    c.notifiyorder(orders);


                } catch (JSONException e) {
                    e.printStackTrace();
                    Toast.makeText(c.getActivity(), "Json"+e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
                }


            }
        }, new Response.ErrorListener() { //Create an error listener to handle errors appropriately.
            @Override
            public void onErrorResponse(VolleyError error) {
                //This code is executed if there is an error.
                if(error!=null)
                    Log.e("error",error.getLocalizedMessage()+"");

            }
        }) {
            protected Map<String, String> getParams() {
                Map<String, String> MyData = new HashMap<String, String>();

//Add the data you'd like to send to the server.
                return MyData;
            }
        };

        MyStringRequest.setRetryPolicy(new DefaultRetryPolicy(
                20 * 1000,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        MySingleton.getInstance(c.getActivity()).addToRequestQueue(MyStringRequest);

    }

    public void addorder(String userid, CartFragment c, CartProduct[] cartProducts){

        String url = "https://fakestoreapi.com/carts";


        JSONObject body = new JSONObject();
        String jsonBody;
        try {
            body.put("token",c.getActivity().getSharedPreferences("onlineapp",MODE_PRIVATE).getString("token",""));
            body.put("userId",userid);
            body.put("date", Calendar.getInstance().getTime().toString());
            body.put("products",cartProducts);

//            Toast.makeText(getActivity(), "In Nudity Present func 1", Toast.LENGTH_SHORT).show();

        } catch (JSONException e) {

        }



        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest
                (Request.Method.POST, url, body, new Response.Listener<JSONObject>() {


                    @Override
                    public void onResponse(JSONObject response) {

                    c.response(true);
                        Toast.makeText(c.getActivity(),"Order Places Successfully", Toast.LENGTH_SHORT).show();

                    }
                }, new Response.ErrorListener() {

                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // TODO: Handle error
                        Toast.makeText(c.getActivity(), "Some error occured", Toast.LENGTH_SHORT).show();
                        c.response(false);

                    }
                });
        MySingleton.getInstance(c.getActivity()).addToRequestQueue(jsonObjectRequest);


    }
}
