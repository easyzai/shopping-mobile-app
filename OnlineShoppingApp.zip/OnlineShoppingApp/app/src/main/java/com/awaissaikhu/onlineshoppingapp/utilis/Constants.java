package com.awaissaikhu.onlineshoppingapp.utilis;

import com.awaissaikhu.onlineshoppingapp.models.Cartitem;

import java.util.ArrayList;

public class Constants {
public  static  ArrayList<Cartitem> cartitems=new ArrayList<>();
}
