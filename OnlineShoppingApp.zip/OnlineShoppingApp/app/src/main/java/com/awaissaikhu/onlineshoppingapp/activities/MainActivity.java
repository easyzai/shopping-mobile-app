package com.awaissaikhu.onlineshoppingapp.activities;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.lifecycle.Lifecycle;
import androidx.viewpager2.adapter.FragmentStateAdapter;
import androidx.viewpager2.widget.ViewPager2;

import android.os.Bundle;

import com.awaissaikhu.onlineshoppingapp.R;
import com.awaissaikhu.onlineshoppingapp.fragments.CartFragment;
import com.awaissaikhu.onlineshoppingapp.fragments.OrderFragment;
import com.awaissaikhu.onlineshoppingapp.fragments.ProfileFragment;
import com.awaissaikhu.onlineshoppingapp.fragments.ShopFragment;
import com.google.android.material.tabs.TabLayout;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    ViewPager2 viewPager;
    TabLayout tabLayout;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        viewPager = findViewById(R.id.viewpager);
        tabLayout = findViewById(R.id.tablayout);
        FragmentManager fm = getSupportFragmentManager();
        ViewStateAdapter sa = new ViewStateAdapter(fm, getLifecycle());
        viewPager.setAdapter(sa);
        tabLayout.addTab(tabLayout.newTab().setIcon(R.drawable.shop));
        tabLayout.addTab(tabLayout.newTab().setIcon(R.drawable.shoppingcart));
        tabLayout.addTab(tabLayout.newTab().setIcon(R.drawable.orders));
        tabLayout.addTab(tabLayout.newTab().setIcon(R.drawable.user));
        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                viewPager.setCurrentItem(tab.getPosition());
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });
        viewPager.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override
            public void onPageSelected(int position) {
                tabLayout.selectTab(tabLayout.getTabAt(position));
            }
        });
    }
    private class ViewStateAdapter extends FragmentStateAdapter {

        public ViewStateAdapter(@NonNull FragmentManager fragmentManager, @NonNull Lifecycle lifecycle) {
            super(fragmentManager, lifecycle);
        }

        @NonNull
        @Override
        public Fragment createFragment(int position) {
            // Hardcoded in this order, you'll want to use lists and make sure the titles match
            if (position == 0) {
                return new ShopFragment();
            } else if (position == 1) {
                return new CartFragment();
            } else if (position == 2) {
                return new OrderFragment();
            }
            return new ProfileFragment();
        }

        @Override
        public int getItemCount() {
            // Hardcoded, use lists
            return 4;
        }
    }
}
