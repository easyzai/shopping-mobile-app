package com.awaissaikhu.onlineshoppingapp.Adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.awaissaikhu.onlineshoppingapp.R;
import com.awaissaikhu.onlineshoppingapp.activities.ProductsActivity;
import com.awaissaikhu.onlineshoppingapp.activities.SingleProductActivity;
import com.awaissaikhu.onlineshoppingapp.models.Order;
import com.awaissaikhu.onlineshoppingapp.models.Product;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;


public class OrderAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {


        PlacesViewHolder placesViewHolder=null;
    Context context;
    ArrayList<Order> orders;
    public OrderAdapter(Context context, ArrayList<Order> orders) {
        this.context = context;
        this.orders = orders;
    }


    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {


        View view;

            view = LayoutInflater.from(parent.getContext()).inflate(R.layout.singleorder, parent, false);

            PlacesViewHolder placesViewHolder = new PlacesViewHolder(view);


            return placesViewHolder;



    }

    @Override
    public int getItemViewType(int position) {


        return position;
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {

            placesViewHolder = (PlacesViewHolder) holder;
            placesViewHolder.txttitle.setText( "Order ID : "+orders.get(position).getId());
            placesViewHolder.txtprice.setText("Dated : \n"+ orders.get(position).getDate());
             placesViewHolder.view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                context.startActivity(new Intent(context, ProductsActivity.class).putExtra("order",orders.get(position)));
            }
        });

    }

    @Override
    public int getItemCount() {
        return orders.size();
    }

    public static class PlacesViewHolder extends RecyclerView.ViewHolder {

        View view;
        TextView txttitle;
        TextView txtprice;


        public PlacesViewHolder(View itemView) {
            super(itemView);
            view = itemView;

            txttitle = (TextView) view.findViewById(R.id.txttitle);
            txtprice = (TextView) view.findViewById(R.id.txtprice);


        }


    }



}
