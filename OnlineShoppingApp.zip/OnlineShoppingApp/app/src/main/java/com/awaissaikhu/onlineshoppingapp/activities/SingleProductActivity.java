package com.awaissaikhu.onlineshoppingapp.activities;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

import com.awaissaikhu.onlineshoppingapp.R;
import com.awaissaikhu.onlineshoppingapp.models.Cartitem;
import com.awaissaikhu.onlineshoppingapp.models.Product;
import com.awaissaikhu.onlineshoppingapp.utilis.Constants;
import com.awaissaikhu.onlineshoppingapp.viewmodel.ProductData;
import com.squareup.picasso.Picasso;

public class SingleProductActivity extends AppCompatActivity {
Product product;
TextView txtquantity,txtname,txtprice,txtdesp,txtrating;
Button btnadd;
ImageView plus,minus,img;
    RatingBar ratingBar;
int qnty=1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_single_product);
         ratingBar=findViewById(R.id.ratingbar);
         txtname=findViewById(R.id.prodcutname);
         txtprice=findViewById(R.id.txtprice);
         txtdesp=findViewById(R.id.productdesp);
        plus=findViewById(R.id.plus);
        minus=findViewById(R.id.minus);
        txtquantity=findViewById(R.id.txtquantity);
         img=findViewById(R.id.img);
         txtrating=findViewById(R.id.txtrating);
        if(getIntent().hasExtra("productid")){
            new ProductData().getsingleproduct(SingleProductActivity.this,getIntent().getIntExtra("productid",1));
        }
        else {
            product = (Product) getIntent().getSerializableExtra("product");
            inidata();
        }

         btnadd=findViewById(R.id.btnaddtocart);
        plus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                    qnty++;
                    txtquantity.setText(qnty+"");

            }
        });
        minus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(qnty>1){
                    qnty--;
                    txtquantity.setText(qnty+"");
                }
            }
        });
        btnadd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                        Constants.cartitems.add(new Cartitem(Constants.cartitems.size() + 1, product, Integer.parseInt(txtquantity.getText().toString())));
                    AlertDialog.Builder builder = new AlertDialog.Builder(SingleProductActivity.this);
                    builder.setTitle("Successfully added");
                    builder.setMessage("Item Successfully places into cart");
                    builder.setPositiveButton("Continue", new DialogInterface.OnClickListener() {

                        public void onClick(DialogInterface dialog, int which) {
                            finish();
                            dialog.dismiss();
                        }
                    });

                    AlertDialog alert = builder.create();
                    alert.show();

            }
        });


    }
    public void inidata(){
        ratingBar.setRating(product.getRating().getRate());
        txtname.setText(product.getTitle());
        txtdesp.setText(product.getDescription());
        txtprice.setText("£ "+product.getPrice()+"");
        txtrating.setText("("+product.getRating().getCount()+")");
        Picasso.get().load(product.getImage()).error(R.drawable.shoppingbag).into(img);


    }

    public void notifiy(Product p) {
        product=p;
        inidata();
    }
}