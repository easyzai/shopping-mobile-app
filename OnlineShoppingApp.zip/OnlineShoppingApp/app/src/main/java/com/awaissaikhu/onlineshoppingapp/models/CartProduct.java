package com.awaissaikhu.onlineshoppingapp.models;

import java.io.Serializable;

public class CartProduct implements Serializable {
    int productId;
    int quantity;

    public CartProduct() {
    }

    public int getProductId() {
        return productId;
    }

    public void setProductId(int productId) {
        this.productId = productId;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
}
